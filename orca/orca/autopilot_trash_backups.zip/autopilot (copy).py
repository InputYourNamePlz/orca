##########################################################
# AUTOPILOT NODE 다. 졸립다..ㅠㅠ
##########################################################

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy, QoSReliabilityPolicy
from rclpy.qos import QoSProfile

import math
import numpy as np
import matplotlib.pyplot as plt
import quaternion
import time
import ray
ray.init()


from orca_interfaces.msg import OrcaPose
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32

from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point


@ray.remote
class Autopilot(Node):

    lidar_ranges=np.array([])
    lidar_angle_min=0.0
    lidar_angle_max=0.0
    lidar_angle_increment=0.0
    points_xy=np.array([])

    waypoint_x=0.0
    waypoint_y=0.0
    current_x=0.0
    current_y=0.0
    current_yaw=0.0
    arrival_radius=0.0

    waypoint_relative_x=0.0
    waypoint_relative_y=0.0

    jump_distance = 0.2
    tree_node_count = 15
    spreading_angle = 0.05
    max_iteration = 1000
    obstacle_avoidance_radius = 0.01
    
    turn_panelty_k = 1.0115
    heading_to_wp_panelty_k = 1.00

    tree=np.empty([])
    tree_isAvailable=np.array([])
    route_node_count=np.array([])


    def __init__(self):
        super().__init__('autopilot')
        
        qos_profile = QoSProfile(depth=10)
        qos_profile.reliability = QoSReliabilityPolicy.BEST_EFFORT
        qos_profile.durability = QoSDurabilityPolicy.VOLATILE
        
        self.lidar_subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.lidar_callback,
            10#qos_profile
            )
        
        self.waypoint_pose_subscription = self.create_subscription(
            OrcaPose,
            '/waypoint_pose',
            self.waypoint_pose_callback,
            10
            )
        
        self.current_pose_subscription = self.create_subscription(
            OrcaPose,
            '/current_pose',
            self.current_pose_callback,
            10
            )
        
        self.arrival_radius_subscription = self.create_subscription(
            Float32,
            '/arrival_radius',
            self.arrival_radius_callback,
            10
        )
        
        self.timer = self.create_timer(1.0, self.timer_callback)

        self.marker_publisher = self.create_publisher(Marker, 'apf_marker', 10)
        self.marker2_publisher = self.create_publisher(Marker, 'apf_marker2', 10)
        




    ##########################################################
    
    def waypoint_pose_callback(self, waypoint_pose_msg):
        self.waypoint_x=waypoint_pose_msg.x
        self.waypoint_y=waypoint_pose_msg.y

    def current_pose_callback(self, current_pose_msg):
        self.current_x=current_pose_msg.x
        self.current_y=current_pose_msg.y
        self.current_yaw=current_pose_msg.yaw

    def arrival_radius_callback(self, arrival_radius_msg):
        self.arrival_radius = arrival_radius_msg.data

    def lidar_callback(self, lidar_msg):
        self.lidar_ranges = np.array(lidar_msg.ranges)
        self.lidar_angle_max = lidar_msg.angle_max
        self.lidar_angle_min = lidar_msg.angle_min
        self.lidar_angle_increment = lidar_msg.angle_increment

        #print("%.1f, %.1f, %.1f, %.1f" % (self.lidar_ranges[0], self.lidar_ranges[90], self.lidar_ranges[180], len(self.lidar_ranges)))

    ##########################################################



    def timer_callback(self):

        start = time.time()

        # 벡터 연산을 통해 빠르게 각 Point에 대한 Radian 값 저장
        if (len(self.lidar_ranges)==0):
            return
    



        if (self.lidar_angle_increment<0):
            points_radian=self.lidar_angle_max - self.lidar_angle_increment * np.arange(len(self.lidar_ranges))
        else:
            points_radian=self.lidar_angle_min + self.lidar_angle_increment * np.arange(len(self.lidar_ranges))
        
        self.points_xy=np.empty((len(self.lidar_ranges),2))
        self.points_xy[:,0] = self.lidar_ranges * np.cos(points_radian)
        self.points_xy[:,1] = self.lidar_ranges * np.sin(points_radian)


        # Waypoint의 상대적 위치 계산
        self.waypoint_relative_x, self.waypoint_relative_y = self.relative_coord_calc()


        self.tree = np.zeros((self.tree_node_count,self.max_iteration, 2))
        self.tree[:,0:2,]=[[0,0],[self.jump_distance,0]] # 첫번째 노드 = 자기위치, 두번째 노드 = 자기 바로 앞


        self.tree[:,2,]=self.next_node_create([0,0],[self.jump_distance,0])

        self.tree_isAvailable = np.full((self.tree_node_count),True)
        self.route_node_count = np.full((self.tree_node_count),2)

        ray.put(self.tree)
        search_tasks=[]
        for i in range(self.tree_node_count):
            #self.tree_search(i, self.waypoint_relative_x, self.waypoint_relative_y)
            search_tasks.append(self.tree_search.remote(i))
        ray.get(search_tasks)
        
            

        available_tree = []

        for i, is_available in enumerate(self.tree_isAvailable):
            if is_available:
                available_tree.extend([ self.tree[i][:self.route_node_count[i]].tolist() ])

        available_tree = sorted(np.array(available_tree), key=len)

        #for haha, hello in enumerate(available_tree):
        #    print(f'{haha} st route length :{len(hello)}')
        if (len(available_tree)!=0):
            print(len(available_tree[4]))
            marker = Marker()
            marker.header.frame_id = 'base_link'
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.type = Marker.LINE_STRIP
            marker.action = Marker.ADD
            marker.pose.orientation.w = 1.0
            marker.scale.x = 0.1  # 선의 두께

            # 라인의 색상 설정 (RGB)
            marker.color.r = 1.0
            marker.color.g = 0.0
            marker.color.b = 0.2
            marker.color.a = 1.0

            # 점 추가
            for x, y in available_tree[4]:
                point = Point()
                point.x = x
                point.y = y
                point.z = 0.0  # 2D 좌표평면에 표시하기 때문에 z는 0
                marker.points.append(point)

            self.marker_publisher.publish(marker)






        end=time.time()


        print('x : %.3f , y : %.3f, lidarLength : %d, time : %.1f' % (self.waypoint_relative_x, self.waypoint_relative_y, len(self.lidar_ranges), (end-start)*1000.0 ) )

        #time.sleep(5)


        #quat = quaternion.from_euler_angles(0,0,np.arctan2(self.waypoint_relative_y, self.waypoint_relative_x))







    def next_node_create(self, prev_node, current_node):
        next_node_array=np.full( (self.tree_node_count,2),[current_node[0],current_node[1]] )

        if (self.tree_node_count%2==1): # 노드 홀수개 만들 때
            radians = self.spreading_angle * np.arange( -(self.tree_node_count-1)/2 , (self.tree_node_count-1)/2+1 )
        else: # 노드 짝수개 만들 때
            radians = (self.spreading_angle/2) * np.arange( -(self.tree_node_count-1), (self.tree_node_count-1)+2, 2)

        
        yaws = np.full( (self.tree_node_count), np.arctan2(current_node[1]-prev_node[1], current_node[0]-prev_node[0]) ) - radians



        next_node_array[:,0]= next_node_array[:,0] + self.jump_distance * np.cos(yaws)
        next_node_array[:,1]= next_node_array[:,1] + self.jump_distance * np.sin(yaws)

        return next_node_array

    @ray.remote
    def tree_search(self, i):
        index = 1
        while True:

            # 마지막 노드가 원 안에 도착했는지 확인. 확인했으면 걍 둘려보냄
            if np.sqrt( (self.tree[i, index , 0]-self.waypoint_relative_x)**2 + (self.tree[i, index , 1]-self.waypoint_relative_y)**2 ) < self.arrival_radius:
                
                return
            if (index>self.max_iteration-2):
                return

            # 앞에 놓을 노드들의 후보를 받아옴
            next_nodes = self.next_node_create(self.tree[i,index-1],self.tree[i,index])
            # 후보들의 점수표
            next_nodes_score=np.zeros((self.tree_node_count))

            #print(next_nodes)
            

            # 후보 오디션을 시ㅣㅣ이이이ㅣ자아ㅏ아아아악
            for idx, next_node in enumerate(next_nodes):

                # lidar 점이랑 가까운게 있으면 컽.
                distances = np.sqrt( (self.points_xy[:,0] - next_node[0])**2 + (self.points_xy[:,1] - next_node[1])**2 )
                points_count_within_radius = distances[distances<self.obstacle_avoidance_radius]
                if (len(points_count_within_radius)!=0):
                    next_nodes_score[idx]=-np.inf
                    continue

                prev_vector = self.tree[i, index,] - self.tree[i, index-1,]
                current_vector = next_node - self.tree[i, index,]
                wp_vector = [self.waypoint_relative_x, self.waypoint_relative_y] - next_node


                heading_difference = np.arccos(  np.dot(prev_vector, current_vector) / (np.linalg.norm(prev_vector)*np.linalg.norm(current_vector))  )
                waypoint_heading_difference = np.arccos(  np.dot(current_vector,wp_vector) / (np.linalg.norm(wp_vector)*np.linalg.norm(current_vector))  )
                # 점수 써넣기
                next_nodes_score[idx] = -heading_difference * self.turn_panelty_k - waypoint_heading_difference * self.heading_to_wp_panelty_k

            

            if ( np.any(next_nodes_score>(-10000)) != True ):
                print("no available next nodes")
                self.tree_isAvailable[i] = False
                return
            optimal_next_node = next_nodes[np.argmax(next_nodes_score)]


            #print(f"next node : {optimal_next_node[0]},{optimal_next_node[1]} , wp : {self.waypoint_relative_x-optimal_next_node[0]},{self.waypoint_relative_y-optimal_next_node[1]}")

            self.tree[i, index+1,]=optimal_next_node
            index+=1
            self.route_node_count[i]+=1











    def relative_coord_calc(self):
        
        relative_x = self.waypoint_x - self.current_x
        relative_y = self.waypoint_y - self.current_y
        distance = np.sqrt(relative_x**2 + relative_y**2)
        waypoint_yaw = np.arctan2(relative_y, relative_x)
        relative_x_coord = distance * np.cos(waypoint_yaw - self.current_yaw)
        relative_y_coord = distance * np.sin(waypoint_yaw - self.current_yaw)
        return relative_x_coord, relative_y_coord












def main(args=None):
    rclpy.init(args=args)
    autopilot = Autopilot()
    rclpy.spin(autopilot)
    autopilot.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()